package com.example.login_2023.presentation.login.navigation

import androidx.navigation.NamedNavArgument

sealed class Destinations(
    val route : String,
){
    object LoginScreen : Destinations( route="LoginScreen/{nameValue}"){
        fun crearRouteNueva(nameValue : String) : String{
            return  "LoginScreen/$nameValue"
        }
    }
    object HomeScreen : Destinations(route = "HomeScreen/{user}"){
        fun createRoute(user : String): String{
            return "homeScreen/$user"
        }
    }
    object RegistrationScreen : Destinations(route = "RegistrationScreen")
    object ForgotPassword : Destinations(route = "ForgotPassword")
}
